package com.org.Task_Managem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskManagemApplication.class, args);
	}

}
